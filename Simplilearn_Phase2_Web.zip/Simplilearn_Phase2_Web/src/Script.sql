create database flight_db;

create table user_reg(id Not Null Int,
Username Varchar(255),
DOB date,
Email Varchar(255),
Password Varchar(255),
type Varchar(50)
);

create user_reg(id Not Null Int,
flight_name Varchar(50),
source_city Varchar(50),
dest_city Varchar(50),
date Varchar date
);

insert into flight_details values(1001,'Indigo','Banglore','Delhi','2021-05-22');
insert into flight_details values(1002,'Spice Jet','Gujarat','Delhi','2021-05-23');
insert into flight_details values(1003,'Air India','Jaipur','Delhi','2021-05-24');



insert into user_reg values (101,'Vijay','1980-06-22','vijay@gmail.com','vijay','user');
insert into user_reg values (101,'Vijay','1990-09-20','chanchal@gmail.com','chanchal','admin');
insert into user_reg values (101,'Vijay','1970-01-02','jagdeesh@gmail.com','jagdeesh','user');
